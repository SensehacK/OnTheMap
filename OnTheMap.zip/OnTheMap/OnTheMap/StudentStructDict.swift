//
//  StudentStructDict.swift
//  OnTheMap
//
//  Created by Sensehack on 18/11/16.
//  Copyright © 2016 Sensehack. All rights reserved.
//

import Foundation

class StudentStructDict {
    
    var studentsDict : [StudentInfo] = []
    static let sharedInstance = StudentStructDict()
    
}
