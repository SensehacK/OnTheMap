//
//  UserInfo.swift
//  OnTheMap
//
//  Created by Sensehack on 17/11/16.
//  Copyright © 2016 Sensehack. All rights reserved.
//

import Foundation

//Changed from class to struct
struct UserInfo {
    
    static var firstName = ""
    static var lastName = ""
    static var userKey = ""
    static var objectID = "" // changed from var to Let
    static var MapLongitude = 0.00
    static var MapLatitude = 0.00
    static var MapString = ""
    static var UserURLStatus = ""
 
}
